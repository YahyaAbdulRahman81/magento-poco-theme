var config = {
    map: {
        '*': {
            'magebees/ajaxcomparewishlist': 'Magebees_Ajaxcomparewishlist/js/ajax-compare',
			'ajaxWishlist': 'Magebees_Ajaxcomparewishlist/js/ajaxwishlist',
            'wishlist': 'Magebees_Ajaxcomparewishlist/js/wishlist'   
        }
    }
};
