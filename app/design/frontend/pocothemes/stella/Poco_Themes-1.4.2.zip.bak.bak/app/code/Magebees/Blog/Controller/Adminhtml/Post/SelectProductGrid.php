<?php
namespace Magebees\Blog\Controller\Adminhtml\Post;
class SelectProductGrid extends Producttab
{

}
