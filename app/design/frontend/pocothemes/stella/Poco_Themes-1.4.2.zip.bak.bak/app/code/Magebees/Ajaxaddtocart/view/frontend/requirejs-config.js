var config = {
    map: {
        '*': {
               
            ajaxToCart: 'Magebees_Ajaxaddtocart/js/ajax-to-cart',
            ajaxConfigurable: 'Magebees_Ajaxaddtocart/js/configurable',
            ajaxPriceBox: 'Magebees_Ajaxaddtocart/js/price-box',
			ajaxPriceConfig: 'Magebees_Ajaxaddtocart/js/price-config',
            ajaxSwatchRenderer: 'Magebees_Ajaxaddtocart/js/SwatchRenderer'
            
        
        }
    },
     config: {
        mixins: {
            'mage/redirect-url': {
                'Magebees_Ajaxaddtocart/js/redirect-url': true
            }
            
        }
    }
};
 