/* A polyfill for browsers that don't support ligatures. */
/* The script tag referring to this file must be placed before the ending body tag. */

/* To provide support for elements dynamically added, this script adds
   method 'icomoonLiga' to the window object. You can pass element references to this method.
*/
(function () {
    'use strict';
    function supportsProperty(p)
    {
        var prefixes = ['Webkit', 'Moz', 'O', 'ms'],
            i,
            div = document.createElement('div'),
            ret = p in div.style;
        if (!ret) {
            p = p.charAt(0).toUpperCase() + p.substr(1);
            for (i = 0; i < prefixes.length; i += 1) {
                ret = prefixes[i] + p in div.style;
                if (ret) {
                    break;
                }
            }
        }
        return ret;
    }
    var icons;
    if (!supportsProperty('fontFeatureSettings')) {
        icons = {
            'google-plus': '&#xea88;',
            'brand2': '&#xea88;',
            'google-plus2': '&#xea89;',
            'brand3': '&#xea89;',
            'google-plus3': '&#xea8a;',
            'brand4': '&#xea8a;',
            'facebook': '&#xea8c;',
            'brand6': '&#xea8c;',
            'facebook2': '&#xea8d;',
            'brand7': '&#xea8d;',
            'facebook3': '&#xea8e;',
            'brand8': '&#xea8e;',
            'twitter': '&#xea91;',
            'brand11': '&#xea91;',
            'twitter2': '&#xea92;',
            'brand12': '&#xea92;',
            'twitter3': '&#xea93;',
            'brand13': '&#xea93;',
            'linkedin': '&#xeac8;',
            'brand63': '&#xeac8;',
            'linkedin2': '&#xeac9;',
            'brand64': '&#xeac9;',
            'pinterest': '&#xead0;',
            'brand71': '&#xead0;',
            'pinterest2': '&#xead1;',
            'brand72': '&#xead1;',
            '0': 0
        };
        delete icons['0'];
        window.icomoonLiga = function (els) {
            var classes,
                el,
                i,
                innerHTML,
                key;
            els = els || document.getElementsByTagName('*');
            if (!els.length) {
                els = [els];
            }
            for (i = 0;; i += 1) {
                el = els[i];
                if (!el) {
                    break;
                }
                classes = el.className;
                if (/icon-/.test(classes)) {
                    innerHTML = el.innerHTML;
                    if (innerHTML && innerHTML.length > 1) {
                        for (key in icons) {
                            if (icons.hasOwnProperty(key)) {
                                innerHTML = innerHTML.replace(new RegExp(key, 'g'), icons[key]);
                            }
                        }
                        el.innerHTML = innerHTML;
                    }
                }
            }
        };
        window.icomoonLiga();
    }
}());