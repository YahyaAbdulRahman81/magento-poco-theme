<?php
namespace Magebees\Blog\Controller\Adminhtml\Post;
class SelectTagGrid extends Tagtab
{

}
