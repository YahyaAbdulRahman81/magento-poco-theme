var config = {
    paths: {
         "magebeesInfiniteScroll": "Magebees_AjaxInfiniteScroll/js/magebeesInfiniteScroll"
    },
    shim: {
        'magebeesInfiniteScroll': {
            deps: ['jquery']
        }
        
        
    }
};



