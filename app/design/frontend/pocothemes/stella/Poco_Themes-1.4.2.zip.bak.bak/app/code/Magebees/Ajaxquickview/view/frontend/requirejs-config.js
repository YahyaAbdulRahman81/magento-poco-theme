var config = {
    map: {
        '*': {
               
            ajaxQuickView: 'Magebees_Ajaxquickview/js/ajax-quickview',
            quickviewConfigurable: 'Magebees_Ajaxquickview/js/configurable',
            ajaxProcessReviews: 'Magebees_Ajaxquickview/js/process-reviews'
        
        }
    },
    paths: {
    },
};
 
