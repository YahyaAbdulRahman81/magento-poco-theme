var config = {
    map: {
        "*": {
            'ajaxloadcategory': 'Magebees_AjaxCategoryProducts/js/ajaxloadcategory',
            'ajaxloadnext': 'Magebees_AjaxCategoryProducts/js/ajaxloadnext',
        }
    }
};