<?php

namespace Magebees\Advertisementblock\Model;

class Advertisementinfo extends \Magento\Framework\Model\AbstractModel
{
    protected function _construct()
    {
        $this->_init('Magebees\Advertisementblock\Model\ResourceModel\Advertisementinfo');
    }
}
