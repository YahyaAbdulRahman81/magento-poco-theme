<?php
namespace Magebees\Blog\Controller\Adminhtml\Post;
class SelectPostGrid extends Posttab
{

}
