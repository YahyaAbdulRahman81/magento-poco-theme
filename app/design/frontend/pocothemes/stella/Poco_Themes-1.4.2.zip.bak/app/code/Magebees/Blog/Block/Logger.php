<?php
namespace Magebees\Blog\Block;
class Logger extends \Monolog\Logger
{
	
}