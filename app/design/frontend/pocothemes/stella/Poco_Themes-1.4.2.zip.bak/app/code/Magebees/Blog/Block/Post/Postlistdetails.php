<?php
namespace Magebees\Blog\Block\Post;
class Postlistdetails extends \Magebees\Blog\Block\Post\Postlist {
 	
	protected function _prepareLayout() {
        return $this;
    } 
}

